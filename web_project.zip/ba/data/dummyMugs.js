module.exports = [
    {
      _id: 'mug123',
      name: 'Pavilion‑Retirement 20 oz. Mug',
      image: 'https://i5.walmartimages.com/seo/Pavilion-Retirement-20-oz-Mug_247dbbaa-6650-4954-b386-e711abd30603.07e1739186e09c12333385e63a4f819b.jpeg',
      amazonPrice: 24.99,
      walmartPrice: 22.5,
      url: 'https://www.walmart.com/ip/Pavilion-Retirement-20-oz-Mug/669843584?classType=REGULAR'
    },
    {
      _id: 'mug124',
      name: 'Hallmark White Ceramic Coffee Mug with Gold Handle',
      image: 'https://i5.walmartimages.com/seo/Pavilion-Retirement-20-oz-Mug_247dbbaa-6650-4954-b386-e711abd30603.07e1739186e09c12333385e63a4f819b.jpeg',
      amazonPrice: 19.99,
      walmartPrice: 17.47,
      url: 'https://www.walmart.com/ip/Pavilion-Retirement-20-oz-Mug/669843584?classType=REGULAR'
    },
    {
      _id: 'mug125',
      name: 'Mainstays Stackable 15 oz Ceramic Coffee Mugs, Set of 6',
      image: 'https://i5.walmartimages.com/seo/Pavilion-Retirement-20-oz-Mug_247dbbaa-6650-4954-b386-e711abd30603.07e1739186e09c12333385e63a4f819b.jpeg',
      amazonPrice: 29.95,
      walmartPrice: 25.84,
      url: 'https://www.walmart.com/ip/Pavilion-Retirement-20-oz-Mug/669843584?classType=REGULAR'
    },
  ];
  
