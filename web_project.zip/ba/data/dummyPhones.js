module.exports = [
    {
      _id: 'phone101',
      name: 'Apple iPhone 14 (128GB, Midnight)',
      image: 'https://m.media-amazon.com/images/I/61PBLEFPoKL._SX679_.jpg',
      amazonPrice: 729.99,
      walmartPrice: 709.00,
      url: 'https://www.amazon.in/iPhone-16-Pro-Max-512/dp/B0DGHYSLTF?source=ps-sl-shoppingads-lpcontext&ref_=fplfs&smid=AJ6SIZC8YQDZX&th=1'
    },
    {
      _id: 'phone102',
      name: 'Samsung Galaxy S23 5G (128GB, Phantom Black)',
      image: 'https://m.media-amazon.com/images/I/61PBLEFPoKL._SX679_.jpg',
      amazonPrice: 699.99,
      walmartPrice: 679.99,
      url: 'https://www.amazon.in/iPhone-16-Pro-Max-512/dp/B0DGHYSLTF?source=ps-sl-shoppingads-lpcontext&ref_=fplfs&smid=AJ6SIZC8YQDZX&th=1'
    },
    {
      _id: 'phone103',
      name: 'Google Pixel 7 5G (128GB, Obsidian)',
      image: 'https://m.media-amazon.com/images/I/61PBLEFPoKL._SX679_.jpg',
      amazonPrice: 599.00,
      walmartPrice: 549.00,
      url: 'https://www.amazon.in/iPhone-16-Pro-Max-512/dp/B0DGHYSLTF?source=ps-sl-shoppingads-lpcontext&ref_=fplfs&smid=AJ6SIZC8YQDZX&th=1'
    }
  ];
   
//   {
//     _id: 'phone104',
//     name: 'OnePlus 11 5G (256GB, Eternal Green)',
//     image: 'https://m.media-amazon.com/images/I/61PBLEFPoKL._SX679_.jpg',
//     amazonPrice: 749.99,
//     walmartPrice: 729.99,
//     url: 'https://www.amazon.in/iPhone-16-Pro-Max-512/dp/B0DGHYSLTF?source=ps-sl-shoppingads-lpcontext&ref_=fplfs&smid=AJ6SIZC8YQDZX&th=1'
//   },
//   {
//     _id: 'phone105',
//     name: 'Xiaomi 13 Pro (256GB, Ceramic White)',
//     image: 'https://m.media-amazon.com/images/I/61PBLEFPoKL._SX679_.jpg',
//     amazonPrice: 899.99,

//     walmartPrice: 879.99,

//     url: 'https://www.amazon.in/iPhone-16-Pro-Max-512/dp/B0DGHYSLTF?source=ps-sl-shoppingads-lpcontext&ref_=fplfs&smid=AJ6SIZC8YQDZX&th=1'
//   },