export const mockProducts = [
    {
      id: 1,
      name: 'Wireless Headphones',
      image: '/images/headphones.jpg',
      amazonPrice: 299,
      flipkartPrice: 279
    },
    {
      id: 2,
      name: 'Smart Watch Series 5',
      image: '/images/watch.jpg',
      amazonPrice: 199,
      flipkartPrice: 189
    }
  ]
