export const wished = [
    {
      id: 1,
      name: 'Wireless Headphones',
      image: '/images/headphones.jpg',
      amazonPrice: 299,
      flipkartPrice: 279
    }
  ]