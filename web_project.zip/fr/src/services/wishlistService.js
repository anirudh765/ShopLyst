// src/services/wishlistService.js
import api from './api';

export const getWishlist = async () => {
  const token = localStorage.getItem('token');
  return api.get('http://localhost:5000/api/wishlist', {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};

export const addToWishlist = async ({ productId, source, watched, targetPrice }) => {
  const res = await api.post('/wishlist', {
    productId,
    source,        // 'amazon' or 'flipkart'
    watched,
    targetPrice
  });
  return res.data;
};

export const removeFromWishlist = async (id) => {
  const res = await api.delete(`/wishlist/${id}`);
  return res.data;
};

export default {
  getWishlist,
  addToWishlist,
  removeFromWishlist
};
